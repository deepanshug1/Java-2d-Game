/*   */ package tile;
/*   */ 
/*   */ import java.awt.image.BufferedImage;
/*   */ 
/*   */ public class Tile {
/*   */   public BufferedImage image;
/*   */   public boolean collision = false;
/*   */ }


/* Location:              C:\Users\DELL\Downloads\BlueBoyTreasure v1.0.jar!\tile\Tile.class
 * Java compiler version: 12 (56.0)
 * JD-Core Version:       1.1.3
 */