package entity;
import main.GamePanel;
import main.KeyHandler;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player extends Entity{

    GamePanel gp;
    KeyHandler keyH;


    public Player(GamePanel gp,KeyHandler keyH){

        this.gp = gp;
        this.keyH = keyH;
        solidArea = new Rectangle();
        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = 16;
        solidArea.height = 16;
        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues(){
        x = 100;
        y = 100;
        speed = 4;
    direction = "down";  //default direction so any is fine

    }
    public void getPlayerImage(){
        try{
            up1 = ImageIO.read(getClass().getResourceAsStream("/player/maxb1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/player/maxb2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/player/maxf2.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/player/maxf3.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/player/maxl.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/player/maxl1.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/player/maxr.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/player/maxr1.png"));
            deepanshi = ImageIO.read(getClass().getResourceAsStream("/player/up1.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void update(){
        if(keyH.downPressed == true || keyH.leftPressed == true || keyH.upPressed == true || keyH.rightPressed == true){
        if (keyH.upPressed== true){
            direction = "up";
            }
        else if(keyH.downPressed == true){
            direction = "down";

        }
        else if(keyH.leftPressed == true){
            direction = "left";

        }
        else if(keyH.rightPressed == true){
            direction = "right";

        }
        //check collision
        collisionOn = false;
        gp.cChecker.checkTile(this);
        //if collision is false player moves
            if (collisionOn == false){
                switch("direction"){
                    case "up":y -= speed;break;
                    case "down":y += speed; break;
                    case "left": x -= speed; break;
                    case "right": x += speed;break;
                }
            }
        spriteCounter++;
        if(spriteCounter > 15){
            if (spriteNum == 1){
                spriteNum =2;

            }
            else if(spriteNum == 2){
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }}
    public void draw(Graphics2D g2){

//        g2.setColor(Color.white);
//        g2.fillRect(x,y,gp.titleSize,gp.titleSize);

        BufferedImage image = null;
        switch (direction){
            case "up":
                if(spriteNum ==1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }

                break;
            case "down":
                if(spriteNum == 1){
                image = down1;}
                if(spriteNum == 2){
                    image = down2;

                }

                break;
            case "left":
                if(spriteNum == 1){
                image = left1;}
                if(spriteNum == 2){
                    image = left2;
                }
                break;
            case "right":
                if(spriteNum == 1){
                    image = right1;
                }
                if (spriteNum == 2){
                    image = right2;
                }

                break;

        }
        g2.drawImage(image,x,y,gp.tileSize,gp.tileSize,null);

    }



}
