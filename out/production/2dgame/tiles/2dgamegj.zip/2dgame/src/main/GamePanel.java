 package main;
import entity.Player;
import tile.TileManager;

import java.awt.*;
import javax.swing.JPanel;


public class GamePanel extends JPanel implements Runnable{
    //for screen settings
    final int originalTileSize = 16;
    //this is for our tile size i.e., 16*16 pixel
    final int scale = 3;
    // to scale 16 by 3 = 48 pixels
    public int gameState;
    public final int playState=1;
    public final int pauseState=2;

    public final int titleState = 0;
    public final int tileSize = originalTileSize*scale;
    // now its 48*48 pixels
    public final int maxScreenCol = 16;
    public final int maxScreenRow = 12;
    public final int screenWidth = tileSize*maxScreenCol;
    public final int screenHeight = tileSize*maxScreenRow;
    //setting fps for our game
    int FPS = 60;
    TileManager tileM = new TileManager(this);
    KeyHandler keyH = new KeyHandler(this);
    sound music = new sound();
    sound sfz = new sound();

    UI ui = new UI(this);
    Player player = new Player(this,keyH);
    Thread gameThread;
    public CollisionChecker cChecker = new CollisionChecker(this);

    //setting our player ki initial positions
//    int playerX = 100;
//    int playerY = 100;
//    int playerSpeed = 4;

    public GamePanel(){
        this.setPreferredSize((new Dimension(screenWidth,screenHeight)));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
    }
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
        playMusic(0);
        gameState= titleState;

    }

    @Override
    public void run() {
        double drawInterval = 1000000000/FPS;
        // as our time is in nano seconds so it will draw screen in every 16 million
        // nano seconds to give us 60 fps in 1 billion nano seconds
        double nextDrawTime = System.nanoTime() + drawInterval;
        while(gameThread != null){
//            long currentTime = System.nanoTime(); this is just to see current time which isn't required

//            System.out.println("This game is running");
// updating character information
            update();
// draw screen according to updated information
            repaint();

            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;
                if (remainingTime<0){
                    remainingTime = 0;
                }
                Thread.sleep((long) remainingTime);
                nextDrawTime += drawInterval;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void update(){
        if(gameState==playState){
        //to change player position by speed jitne pixels
        player.update();}
        if (gameState == pauseState) {
        }


    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;

        if (gameState == titleState){
            ui.draw(g2);
        }

        else{
            tileM.draw(g2);
            player.draw(g2);
            ui.draw(g2);
            g2.dispose();
        }
    }
    public void playMusic(int i){
        music.setfile(i);
        music.start();
        music.loop();
    }
    public void stopMusic(){
        music.stop();
    }
    public void sfx(int i){
        sfz.setfile(i);
        sfz.start();
    }
}

